#include "functional.h"
#include "tasks.h"
#include "tests.h"
#include <stdlib.h>
#include <string.h>
#include <stdio.h>

typedef void (*func_ptr)(void *);

// tip de date util pt functia generate_matrix
// ajuta la crearea unei liste cu n (retinut in campul len)
// consecutive incepand de la valoare retinuta in start_point
typedef struct start_and_length {
	int start_point;
	int len;
} strt_and_len;

void insert_rev(void *dest, void *src) {
	memcpy(dest, src, sizeof(int));
}

array_t reverse(array_t list) {
	array_t new_list;
	// mutam ptr catre vectorul de date la finalul lui
	// pentru a-l putea parcurge invers
	char *ptr = (char *)list.data;
	list.data = (void *)(ptr + list.elem_size * (list.len - 1));
	list.destructor = NULL;
	// setam elem_size negativ pentru a parcurge lista in sens invers
	// la apelul functiei map
	// o iteratie nu ne va duce cu o celula in fata, ci in spate
	list.elem_size = list.elem_size * (-1);
	new_list = map(insert_rev, sizeof(int), list.destructor, list);
	list.elem_size = sizeof(int);
	ptr = (char *)list.data;
	list.data = (void *)(ptr - list.elem_size * (list.len - 1));
	return new_list;
}

// distructor pt lista de tip number_t
// utila in functia create_number_array
// elibereaza memoria alocata stringului
void numbert_destructor(void *elem)
{
	number_t *aux = (number_t *)elem;
	free(aux->string);
}

// functie care construieste un nr rational
// din partea intreaga si cea fractionara
void build_double (void *dest, void **parts) {
	// fac cast pointerului de rezultat la tipul
	// elementelor noii liste
	number_t *rez = (number_t *)dest;
	// obtin partea fr si cea intreaga din vectorul
	// parts dat ca parametru si le pun in structura
	int *int_part = (int *)parts[0];
	int *fr_part = (int *)parts[1];
	char *int_part_to_char = (char *)malloc(50 * sizeof(char));
	char *fr_part_to_char = (char *)malloc(50 * sizeof(char));
	sprintf(int_part_to_char, "%d", *int_part);
	sprintf(fr_part_to_char, "%d", *fr_part);
	rez->string = (char *)malloc(sizeof(char) * 100);
	rez->string[0] = '\0';
	strcat(rez->string, int_part_to_char);
	rez->string[strlen(rez->string) + 1] = '\0';
	rez->string[strlen(rez->string)] = '.';
	strcat(rez->string, fr_part_to_char);
	free(int_part_to_char);
	free(fr_part_to_char);
}

array_t create_number_array(array_t integer_part, array_t fractional_part)
{
	array_t new_list;
	new_list = map_multiple(build_double, sizeof(number_t), numbert_destructor,
							2, integer_part, fractional_part);
	return new_list;
}

// functie destructor pt lista de tip student
// elibreaza memoria ocupata de nume
void student_destructor(void *data) {
	student_t *aux = (student_t *)data;
	free(aux->name);
}

// functie care verifica nota de trecere a unui elev
// utila in functia 'get_passing_students_names'
boolean passing_grade_check(void *student) {
	student_t *aux = (student_t *)student;
	if (aux->grade >= 5.0)
		return 1;
	return 0;
}

array_t get_passing_students_names(array_t list) {
	array_t new;
	// filtram lista initiala
	new = filter(passing_grade_check, list);
	(void)list;
	return new;
}

void add_acc(void *acc, void *elem) {
	int *aux = (int *)acc;
	*aux = *aux + *(int *)elem;
}

// functie care efectueaza suma elem unei liste
// utila in apelul lui map din check_bigger_sum
void sum_of_list_elem(void *dest, void *src) {
	array_t *src_list = (array_t *)src;
	int *sum = (int *)dest;
	*sum = 0;
	reduce(add_acc, (void *)sum, *src_list);
}

// functie care verifica daca suma unei liste e mai
// mare sau egala decat val sa corespunzatoare din lista
// int_list din check_bigger_sum
void check_val(void *dest, void **src) {
	int *sum = (int *)src[0];
	int *val = (int *)src[1];
	boolean *rez = (boolean *)dest;
	if (*sum >= *val)
		*rez = 1;
	else
		*rez = 0;
}

array_t check_bigger_sum(array_t list_list, array_t int_list) {
	// facem o lista noua cu suma elem fiecarei liste
	array_t list_of_sums;
	// cream lista de sume
	list_of_sums = map(sum_of_list_elem, sizeof(int),
					   NULL, list_list);
	// cream lista boolean
	array_t bool_list;
	// apelam fnct map_multiple
	bool_list = map_multiple(check_val, sizeof(boolean), NULL, 2,
							 list_of_sums, int_list);
	(void)list_list;
	(void)int_list;
	return bool_list;
}

void get_first_half(void *dest, void *src) {
	char **even_strings = (char **)dest;
	char **src_list = (char **)src;
	// am alocat memorie pt stringul curent mutat in noua lista
	*even_strings = (char *)malloc(sizeof(char) * (strlen(*src_list) + 2));
	strcpy(*even_strings, *src_list);
}

void double_chptr_destructor(void *data) {
	char **ptr = (char **)data;
	char *first = ptr[0];
	char *second = ptr[1];
	free(first);
	free(second);
}

array_t get_even_indexed_strings(array_t list) {
	// initializam noua lista in care punem
	// string-urile de la index par
	array_t even_strings;
	// daca avem nr impar de stringuri, mai adaugam unul fals la final
	// ca sa devina nr par si sa le putem lua 2 cate 2
	// adica sa dam dimensiunea unui elem din list ca = sizeof(char *) * 2
	if (list.len % 2 == 1) {
		++list.len;
		list.data = realloc(list.data, sizeof(char *) * list.len);
		// initializez zona extra alocata cu un pointer catre o zona
		// de memorie oarecare pentru a evita un free invalid
		// in cadrul desttructorului
		// pt ca el va incerca sa elibereze a doua pozitie din duplex
		// insa acolo nu e niciun pointer catre o zona de memorie care sa
		// fie eliberata!!
		char **aux = (char **)list.data;
		char *extra = (char *)malloc(sizeof(char));
		*extra = '1';
		aux[list.len - 1] = extra;
	}
	list.len = list.len / 2;
	// schimbam dimensiunea unui elem din list la 2 * sizeof(char *)
	// ca sa putem sari peste stringurile cu index impar
	list.elem_size = 2 * sizeof(char *);
	list.destructor = double_chptr_destructor;
	even_strings = map(get_first_half, sizeof(char *), list.destructor, list);
	return even_strings;
}

void generate_array(void *dest, void *src) {
	strt_and_len *aux_src = (strt_and_len *)src;
	strt_and_len *aux_dest = (strt_and_len *)dest;
	aux_dest->start_point = aux_src->start_point;
	aux_dest->len = aux_src->len;
    // elem listei vechi creste pt urm element din lista noua de la
    // urm iteratie
	aux_src->start_point = aux_src->start_point + 1;
}

void generate_array2(void *dest, void *src) {
	strt_and_len *aux_src = (strt_and_len *)src;
	int *aux_dest = (int *)dest;
	*aux_dest = aux_src->start_point;
    // elem listei vechi creste pt urm element din lista noua de la
    // urm iteratie
	aux_src->start_point = aux_src->start_point + 1;
}

void generate_list_from_head(void *dest, void *src) {
	array_t *dest_list = (array_t *)dest;
	strt_and_len *src_aux = (strt_and_len *)src;
	array_t base_list;
	base_list.data = malloc(sizeof(strt_and_len));
	base_list.destructor = NULL;
	base_list.elem_size = 0;
	base_list.len = src_aux->len;
	*(strt_and_len *)base_list.data = *src_aux;
	*dest_list = map(generate_array2, sizeof(int), NULL, base_list);
	free(base_list.data);
}

void list_destructor(void *data) {
	array_t *aux = (array_t *)data;
	free(aux->data);
}

array_t generate_square_matrix(int n) {
	// creez lista initiala care va contine 1 sg elem cu val n
	array_t list;
	// aloc mem pt un sg elem
	list.data = malloc(sizeof(strt_and_len));
	// punem in lista n
	strt_and_len *aux = (strt_and_len *)list.data;
	aux->start_point = 1;
	aux->len = n;
	list.destructor = NULL;
	// setez dimensiunea elem = 0 pt a nu inainta in lista
	// la iteratiile functionalelor aplicate ulterior
	list.elem_size = 0;
	list.len = n;
	array_t new_list;
	new_list = map(generate_array, sizeof(strt_and_len), NULL, list);
	free(list.data);
	// dupa apelarea map, new_list va contine vectorul
	// 1 2 3 ... n-1 n
	array_t final_list = map(generate_list_from_head, sizeof(array_t),
							 list_destructor, new_list);
	return final_list;
}
