#include "functional.h"
#include <stdlib.h>
#include <string.h>
#include <stdarg.h>
#include <stdio.h>

void for_each(void (*func)(void *), array_t list)
{
	int i;
	unsigned char *ptr = (unsigned char *)list.data;
	for (i = 0; i < list.len; i++) {
		func((void *)ptr);
		ptr = ptr + list.elem_size;
	}
	(void)func;
	(void)list;
}

array_t map(void (*func)(void *, void *),
			int new_list_elem_size,
			void (*new_list_destructor)(void *),
			array_t list)
{
	array_t new_list;
	// initializam lista noua
	new_list.data = malloc(list.len * new_list_elem_size);
	new_list.destructor = new_list_destructor;
	new_list.elem_size = new_list_elem_size;
	new_list.len = 0;
	int i;
	char *ptr = (char *)list.data;
	for (i = 0; i < list.len; i++) {
		func(new_list.data + i * new_list.elem_size, (void *)ptr);
		++new_list.len;
		if (new_list.len < list.len)
			ptr = ptr + list.elem_size;
	}
	if (list.elem_size > 0) {
		ptr = list.data;
		if (list.destructor) {
			for (i = 0; i < list.len; i++)
				list.destructor((void *)(ptr + i * list.elem_size));
		}
		free(list.data);
	}
	return new_list;
}

array_t filter(boolean(*func)(void *), array_t list)
{
	array_t new_list;
	// initializam lista noua
	new_list.data = malloc(list.len * list.elem_size);
	new_list.destructor = list.destructor;
	new_list.elem_size = list.elem_size;
	new_list.len = 0;
	int i, j;
	char *ptr = (char *)list.data;
	for (i = 0; i < list.len; i++) {
		// daca elem respecta conditia
		if (func((void *)ptr)) {
			// il mutam
			for (j = 0; j < new_list.elem_size; j++) {
				*((char *)new_list.data + new_list.len *
				new_list.elem_size + j) = *((char *)list.data +
				i * list.elem_size + j);
			}
			++new_list.len;
		}
		if (new_list.len < list.len)
			ptr = ptr + list.elem_size;
	}
	free(list.data);
	return new_list;
}

void *reduce(void (*func)(void *, void *), void *acc, array_t list)
{
	unsigned char *ptr = (unsigned char *)list.data;
	int i;
	for (i = 0; i < list.len; i++) {
		func(acc, ptr);
		ptr = ptr + list.elem_size;
	}
	(void)func;
	(void)acc;
	(void)list;
	return NULL;
}

void for_each_multiple(void(*func)(void **), int varg_c, ...)
{
	va_list params;
	va_start(params, varg_c);
	int min_index, j;
	// caut lista cu lungimea cea mai mica
	for (j = 1; j <= varg_c; j++) {
		// trec la urm lista din antetul functiei
		// list o sa contina ptr la aceasta
		array_t current = va_arg(params, array_t);
		// daca ne aflam la prima lista => min_index =
		// neinitializat => il initializam cu lungimea
		// primei liste
		if (j == 1) {
			min_index = current.len;
		} else {
			// altfel verificam daca lungimea listei curente
			// e mai mica decat min; daca da, min = lungimii ei
			if (min_index > current.len)
				min_index = current.len;
		}
	}
	//aloc memorie vect de elem de index j din toate listele
	void **elem_index_j = malloc(varg_c * sizeof(void *));
	// aplicam func pt toate elem =>0 & <min_index din toate listele
	for (j = 0; j < min_index; j++) {
		va_start(params, varg_c);
		int i;
		// parcurgere liste pt extragere ptr catre elem cu index j
		for (i = 0; i < varg_c; i++) {
			// trec la urm lista
			array_t current = va_arg(params, array_t);
			// elem_index_j[i] = ptr catre elem j din current.data
			elem_index_j[i] = current.data + j * current.elem_size;
		}
		func(elem_index_j);
		va_end(params);
	}
	free(elem_index_j);
	va_end(params);
}

array_t map_multiple(void (*func)(void *, void **),
					 int new_list_elem_size,
					 void (*new_list_destructor)(void *),
					 int varg_c, ...)
{
	va_list params;
	va_start(params, varg_c);
	int min_index, j;
	// caut lista cu lungimea cea mai mica
	for (j = 1; j <= varg_c; j++) {
		// trec la urm lista din antetul functiei
		// list o sa contina ptr la aceasta
		array_t current = va_arg(params, array_t);
		// daca ne aflam la prima lista => min_index =
		// neinitializat => il initializam cu lungimea
		// primei liste
		if (j == 1) {
			min_index = current.len;
		} else {
			// altfel verificam daca lungimea listei curente
			// e mai mica decat min; daca da, min = lungimii ei
			if (min_index > current.len)
				min_index = current.len;
		}
	}
	array_t new;
	// initializez noua lista cu un nr de celule = cu
	// lungimea celei mai scurte liste
	new.data = malloc(min_index * new_list_elem_size);
	// initializez lista noua
	new.destructor = new_list_destructor;
	new.elem_size = new_list_elem_size;
	new.len = min_index;
	//aloc memorie vect de elem de index j din toate listele
	void **elem_index_j = malloc(varg_c * sizeof(void *));
	// aplicam func pt toate elem =>0 & <min_index din toate listele
	// aux va stoca elementul curent creat pt a fi adaugat
	// in lista finala
	void *aux = malloc(new_list_elem_size);
	for (j = 0; j < min_index; j++) {
		va_start(params, varg_c);
		int i;
		// parcurgere liste pt extragere ptr catre elem cu index j
		for (i = 0; i < varg_c; i++) {
			// trec la urm lista
			array_t current = va_arg(params, array_t);
			// elem_index_j[i] = ptr catre elem j din current.data
			elem_index_j[i] = current.data + j * current.elem_size;
		}
		func(aux, elem_index_j);
		// mutam aux in lista noua
		for (i = 0; i < new_list_elem_size; i++) {
			*((char *)new.data + j * new_list_elem_size + i) =
			*((char *)aux + i);
		}
		va_end(params);
	}
	va_end(params);
	free(elem_index_j);
	free(aux);
	va_start(params, varg_c);
	int i;
	for (i = 0; i < varg_c; i++) {
		array_t current = va_arg(params, array_t);
		if (current.destructor) {
			void **ptr = (void **)current.data;
			int j;
			for (j = 0; j < current.len; j++)
				current.destructor(ptr + j);
		}
		free(current.data);
	}
	return new;
}

void *reduce_multiple(void(*func)(void *, void **), void *acc, int varg_c, ...)
{
	va_list params;
	va_start(params, varg_c);
	int min_index, j;
	// caut lista cu lungimea cea mai mica
	for (j = 1; j <= varg_c; j++) {
		// trec la urm lista din antetul functiei
		// list o sa contina ptr la aceasta
		array_t current = va_arg(params, array_t);
		// daca ne aflam la prima lista => min_index =
		// neinitializat => il initializam cu lungimea
		// primei liste
		if (j == 1) {
			min_index = current.len;
		} else {
			// altfel verificam daca lungimea listei curente
			// e mai mica decat min; daca da, min = lungimii ei
			if (min_index > current.len)
				min_index = current.len;
		}
	}
	//aloc memorie vect de elem de index j din toate listele
	void **elem_index_j = malloc(varg_c * sizeof(void *));
	// aplicam func pt toate elem =>0 & <min_index din toate listele
	for (j = 0; j < min_index; j++) {
		va_start(params, varg_c);
		int i;
		// parcurgere liste pt extragere ptr catre elem cu index j
		for (i = 0; i < varg_c; i++) {
			// trec la urm lista
			array_t current = va_arg(params, array_t);
			// elem_index_j[i] = ptr catre elem j din current.data
			elem_index_j[i] = current.data + j * current.elem_size;
		}
		func(acc, elem_index_j);
		va_end(params);
	}
	free(elem_index_j);
	va_end(params);
	return NULL;
}
